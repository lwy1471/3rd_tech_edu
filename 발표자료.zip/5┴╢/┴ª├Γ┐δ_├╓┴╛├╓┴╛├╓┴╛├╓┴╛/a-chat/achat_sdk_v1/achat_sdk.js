/*
Title:		OEngine: a SK Conversation Chatbot Plugin
Author:		Choi jaecheol
Version:	0.2.0
Website:
License: 	the MIT and GPL licenses.
*/

(function($) {
	$.fn.extend({
        OEngine: function(options) {
        	var elem = this;
        	var defaults =  {
    			'width' : '25%',
    			'height' : '100%',
    			'bgColor' : '#2e3951',
    			'ctitle' : 'Aibril Chatbot',
    			'firstMsg' : '안녕하세요. Aibril Chatbot 입니다.',
    			'anythingMsg'  :  '죄송합니다. 알아듣기 쉽게 다시 말씀해주시면 좋겠어요.',
    			'api_key' : '',
    			'user_info' : null,
    			'url' : 'https://oe.aibril.com'
    		  }
          if (options && typeof(options) == 'object') {
            options = $.extend( {}, defaults, options );
          }
        	achat.init(elem, options);
          return;
        }
    });
})(jQuery);

var achat = {
		variable : {
			conText : {},
			messagesendFlag : true
		},
		check_auth : function(){
			if(this.options.api_key == '' || this.options.api_key == null){
				alert('권한이 없습니다. api key를 확인 해 주세요.');
			}
		},
		target : null,
		options : {},
		init : function(target, options){
			this.target = target;
			this.options = options;
			this.check_auth();
			this.event();
			this.func.fnSend(achat.options.api_key, '', true);
			$(this.target).find('#achat_date').html('Today , ' + this.func.convertDate(new Date()));
		},
		event : function(){
			$(this.target).find("#achat_input_message").unbind('keypress').keypress(function(e){
				//크로스도메인허용
		    $.support.cors = true;

				//key 초기화
				var result = "";
				//크롬 계열
				if(typeof(e) != "undefined") {
					result = e.which;
				}else {
					result = event.keyCode;
				}
				if (result == 13){
					//엔터 입력시 실행 함수
					var msg = $(achat.target).find("#achat_input_message").val();
					achat.func.fnSend(achat.options.api_key, msg);
				}
			});
			$(this.target).find("#achat_send_message").unbind('click').click(function(){
				var msg = $(achat.target).find("#achat_input_message").val();
				achat.func.fnSend(achat.options.api_key, msg);
			});
		},
		func : {
			convertDate : function(date){
				var yyyy = date.getFullYear().toString();
				var mm = (date.getMonth()+1).toString();
				var dd  = date.getDate().toString();
				var mmChars = mm.split('');
				var ddChars = dd.split('');
				return yyyy + '-' + (mmChars[1]?mm:"0"+mmChars[0]) + '-' + (ddChars[1]?dd:"0"+ddChars[0]);
			},
			fnSend : function(api_key, msg, init_flag){
				achat.check_auth();
				if(!achat.variable.messagesendFlag){
					return false;
				}
				achat.variable.messagesendFlag = false;

				if(!init_flag){
					if(msg.trim() == null ){
						achat.variable.messagesendFlag = true;
						return false;
					}

					if(msg.trim() == '' ){
						achat.variable.messagesendFlag = true;
						return false;
					}
				}

				var data ={};
			  data.api_key = achat.options.api_key;
			  data.user_info = JSON.stringify(achat.options.user_info);
			  data.text = msg;
				data.context = JSON.stringify(achat.variable.conText);
				var _url = achat.options.url;
				$.ajax({
						type : 'POST',
						crossDomain: true,
						cache: false,
						url : _url + '/api/v1.0/wrks/message/',
						dataType : 'json',
						data: data,
						beforeSend:function(){
							//사용자 메시지 출력창.
							if(!init_flag){
								var param = {
										input : {
											text : msg
										}
								};

								$(achat.target).find("#achat_talk_body").achat_render(param);
								$(achat.target).find("#achat_input_message").val("Loading...");
								$(achat.target).find('#achat_input_message').attr('readonly', true);
							}
			      },
						success : function(result){
							console.log(result);

							if(result.output.type=="Link"){
								var resultJson = JSON.parse(result.output.text);
								var itemsJson = resultJson.response.body;
								var linkValue = result.context.linkValue;

								var achatObject = new Object();
								var achatArray = new Array();
								var textObject = new Object();

								if(linkValue=="184" || linkValue=="157") {
									var itemLength = itemsJson.items.item.length;

									for(var key=0; key < itemLength; key++) {
										var listObject = new Object();

										listObject.title = itemsJson.items.item[key].name;
										listObject.response = itemsJson.items.item[key].name;

										achatArray.push(listObject);
									};
									achatObject.ui_type = 'list';

									if(linkValue=="184"){
										textObject.values = '관광 지역을 선택해 주세요.';
									} else if(linkValue=="157"){
										textObject.values = '관광 타입을 선택해 주세요.';
									};
								} else if(linkValue=="183"){
									var itemLength = itemsJson.items.item.length;

									for(var key=0; key < itemLength; key++) {
										var listObject = new Object();

										listObject.img_url = itemsJson.items.item[key].firstimage;
										listObject.img_title = itemsJson.items.item[key].title;

										achatArray.push(listObject);
									};
									achatObject.ui_type = 'img_slider';
								} else if(linkValue=="187"){
									var itemLength = itemsJson.items.item.length;

									for(var key=0; key < itemLength; key++) {
										var listObject = new Object();

										listObject.title = itemsJson.items.item[key].countryName;
										listObject.response = itemsJson.items.item[key].countryName;

										achatArray.push(listObject);
									};
									achatObject.ui_type = 'list';
									textObject.values = '국가를 선택해 주세요.';
								} else if(linkValue=="188"){
									var listObject = new Object();

									listObject.url = 'https://www.0404.go.kr/walking/prohibition_system.jsp';
									listObject.title = '외교부 해외안전여행 사이트';

									achatArray.push(listObject);

									achatObject.ui_type = 'url';
									achatObject.img = new Array(itemsJson.item.imgUrl);
									textObject.values = '# 국가명 : ' + itemsJson.item.countryName + '<br># 금지기간 : ' + itemsJson.item.banNote;
								};
								achatObject.content = achatArray;

								result.context.achat_ui = achatObject;
								result.output.text = textObject;
							};

							result.anythingMsg = achat.options.anythingMsg;
							$(achat.target).find('#achat_talk_body').achat_render(result);
							delete result.context.achat_ui;

							if(result.output.type=="Link"){
								delete result.context.linkValue;
							};

							achat.variable.conText = result.context;
						},
						complete:function(){
							$(achat.target).find("#achat_input_message").val("");
							$(achat.target).find('#achat_input_message').attr('readonly', false);
							$(achat.target).find("#achat_talk_body").scrollTop(9999);  //scroll Y 재조정.
							achat.variable.messagesendFlag = true;
			      },
						error : function(xhr, status, error){
							alert('error' + JSON.stringify(xhr) );
							console.log(error);
						}
				});
			}
		}
}
